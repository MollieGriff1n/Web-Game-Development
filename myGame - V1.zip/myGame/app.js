const express = require('express');
const app = express();
const port = 3000;

var mysql = require('mysql'); 

app.use(express.static('static'));

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "cmp5360"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  con.query("SELECT * FROM user", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });
});



  app.get("/homepage", (req, res) =>{ 
    res.sendFile(__dirname+'/homepage.html');
  })

  app.get("/login", (req, res) =>{ 
    res.sendFile(__dirname+'/login.html');
  })

  app.get("/loading", (req, res) =>{ 
    res.sendFile(__dirname+'/loading.html');
  })

  app.get("/game", (req, res) =>{ 
    res.sendFile(__dirname+'/game.html');
  })

  app.get('/*', (req, res) =>{
    console.log(__dirname);
    res.status(404).sendFile(__dirname+'/404.html')
  })


app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})