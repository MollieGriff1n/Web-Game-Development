import * as THREE from "three";
import { OrbitControls } from 'https://unpkg.com/three@0.169.0/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from "https://unpkg.com/three@0.169.0/examples/jsm/loaders/GLTFLoader.js";
import Stats from 'https://unpkg.com/three@0.169.0/examples/jsm/libs/stats.module.js';



//create....
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );

const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );

let controls;

const color = 0xFFFFFF;
const intensity = 10;
const light = new THREE.DirectionalLight(color, intensity);
light.position.set(0, 0, 0);
light.target.position.set(150, 0, 50);
scene.add(light);
scene.add(light.target);
    
let stats;

stats = new Stats();

document.body.appendChild( stats.dom );

const loader = new GLTFLoader().setPath("resources/3dmodel");

const geometry = new THREE.BoxGeometry( 1, 1, 1 );
const material = new THREE.MeshBasicMaterial( { color: 0x00ff00 } );
const cube = new THREE.Mesh( geometry, material );
scene.add( cube );

camera.position.z = 10;

let heliObj;
loader.load(
  '/Dragon.glb'
  ,
  (gltf)=>{
    heliObj = gltf.scene;
    heliObj.scale.set(0.3, 0.3, 0.3);
    heliObj.position.set(2,2,0);
    scene.add(heliObj);
    
  }
  ,
  (xhr)=>{
    console.log((xhr.loaded/xhr.total *100)+ '% loaded');
  }
  ,
  (error)=>{
    console.log("There is an error when loading GLTF:" + error);
  }
);




function animate() {
	requestAnimationFrame( animate );

	cube.rotation.x += 0.01;
	cube.rotation.y += 0.01;

	renderer.render( scene, camera );

  
  stats.update();
}

function onWindowResize(){

	camera.aspec = window.innerWidth / window.innerHeight;

	camera.updateProjectionMatrix();

	renderer.setSize( window.innerWidth, window.innerHeight);
}

window.addEventListener( 'resize', onWindowResize);

animate();

      //create skybox function
      const createskybox = ()=>{
 
        let bgMesh;
 
        const loader  = new THREE.TextureLoader();
        loader.load('Resources/images/skybox.jpg',function(texture){
             //create a sphere
        let sphereGeometry =new THREE.SphereGeometry(100, 60, 40);
         //set up the sphere texture and make sure it is double sided
        let sphereMaterial  =new THREE.MeshBasicMaterial({
          map: texture,
          side: THREE.DoubleSide
 
        })
 
        //scale the sphere
        sphereGeometry.scale(-1, 1, 1);
 
        bgMesh = new THREE.Mesh(sphereGeometry,sphereMaterial );
        scene.add(bgMesh);
        bgMesh.position.set(0,0,0);
       
 
        })
 
       
      }
 
      //call the skybox fuction
      createskybox();

const createControls=()=>{
	controls = new OrbitControls(camera, renderer.domElement);

	controls.update();

  
}

createControls();

// const moveUp=()
